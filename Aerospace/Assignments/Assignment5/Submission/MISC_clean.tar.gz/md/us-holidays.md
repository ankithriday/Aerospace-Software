---
layout: single
title: US Holidays
permalink: /community/us-holidays/
header:
  overlay_color: "#137bce"
---
## 2017

Date          | Holiday
---           | ---
January 02    | New Years Day
January 16    | Martin Luther King Day (Third Monday in January)
February 20   | Presidents Day (3rd Monday in February)
May 29        | Memorial Day (Last Monday in May)
July 04       | Independence Day
September 04  | Labor Day (First Monday in September)
November 10   |	Veterans Day
November 23-24|	Thanksgiving (Fourth Thursday in November)
December 22   | Christmas Eve
December 25   |	Christmas Day
