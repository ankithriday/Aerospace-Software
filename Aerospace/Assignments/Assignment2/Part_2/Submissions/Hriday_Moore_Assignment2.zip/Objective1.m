function [best_guess, best_thrust,data] = Objective1(guess, thrust_mag_top, Init, constants, time_s, percent,hor_shifts,data_guess,ignore)
% For this I will be taking a greedy approach to finding the optimal
% Need to find the smallest change in delta v which gets the spacecraft
% back to earth

best_guess = [];
best_thrust = [];
data = [];
if hor_shifts == 5   % If I have done enough horizontal searches, then it is time to return
    best_guess = guess;
    best_thrust = thrust_mag_top;
    data = data_guess;
    return
end

%% First find how far I can decrease the magnitude for the current direction
thrust_mag_bottom = 0;
Init_guess = Init;     % make a copy of this so I can have the correct values
for i = 1:15
    thrust_mag = (thrust_mag_top + thrust_mag_bottom) / 2;   % take the average of the top and bottom
    Init_guess(3) = Init(3) + guess(1)*thrust_mag;
    Init_guess(4) = Init(4) + guess(2)*thrust_mag;
    [data_save,code] = calculate_orbit(Init_guess, constants, time_s);
    if code == 1    % has landed in the Earth so can decrease thrust
        thrust_mag_top = thrust_mag;
        data = data_save;                % this is currently the best data
    else
        thrust_mag_bottom = thrust_mag;
    end
    
end

%% Now find if we can change any in the directional sense
good_directions = [];

while isempty(good_directions)
    % there will be 8 directions that I will try
    direction = [];
    direction = [direction;guess(1) + guess(1)*percent, guess(2)];   %East
    direction = [direction;guess(1) - guess(1)*percent, guess(2)];   %West
    direction = [direction;guess(1), guess(2) + guess(2)*percent];   %North
    direction = [direction;guess(1), guess(2) - guess(2)*percent];   %South

     
    
    for i = 1:4
        if ignore == i   % don't need to do repeat calculations
            continue
        end
        % first I need to renormalize the direction
        norm_dir = norm(direction(i,:));
        if ~norm_dir    % if the norm is 0 then skip this loop
            continue
        end
        direction(i,:) = direction(i,:)./norm_dir;
        Init_guess(3) = Init(3) + direction(i,1)*thrust_mag;   % use the good thrust mag calculated before
        Init_guess(4) = Init(4) + direction(i,2)*thrust_mag;

        [data_guess,code] = calculate_orbit(Init_guess, constants, time_s);
        if code == 1
            if i == 1
                ignore_index = 2;   % need to set the next ignore to save time.
            elseif i == 2
                ignore_index = 1;
            elseif i == 3
                ignore_index = 4;
            elseif i == 4
                ignore_index = 3;
            end
            [best_dir,best_mag] = Objective1(direction(i,:), thrust_mag, Init, constants, time_s, percent,hor_shifts + 1,data_guess,ignore_index);
            good_directions = [good_directions;i];
            if isempty(best_mag)    % If I returned nothing, there will be another path which has something
                continue
            elseif isempty(best_thrust)
                best_thrust = best_mag;
                best_guess = best_dir;
                data = data_guess;
            elseif best_mag < best_thrust      % update the return values if they are better
                best_thrust = best_mag;
                best_guess = best_dir;
                data = data_guess;
            end
        end
    end
    if isempty(good_directions)
        percent = percent / 2;   % decrease the search boundary so we can find something inside the paraboloid
        ignore = [];
    end
    if percent < (2^(-16))   % if it is not going to find it in this branch so just return
         best_thrust = thrust_mag_top;
         best_guess = guess;
        return 
    end
        
end



end