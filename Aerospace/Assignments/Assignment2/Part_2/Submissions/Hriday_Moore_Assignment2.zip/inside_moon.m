function [result] = inside_moon(x_moon, y_moon, m_rad, scraft_x, scraft_y)
% This function determines whether or not the space is inside of the moon
% need radius of the space craft
scraft_x = scraft_x - x_moon;
scraft_y = scraft_y - y_moon;

scraft_rad = sqrt(scraft_x^2 + scraft_y^2);

if scraft_rad < m_rad
    result = 1;     % logical true
else
    result = 0;   % logical false
end

end