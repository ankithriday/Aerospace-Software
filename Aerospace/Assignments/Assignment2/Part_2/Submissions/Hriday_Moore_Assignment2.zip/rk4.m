function [cur_vals] = rk4(cur_vals, constants, h)
% h is the time step

% Some integrating stuff
    % Calculate Distances
    d_ES = cur_vals(5);
    d_MS = sqrt((cur_vals(8)-cur_vals(1))^2 + (cur_vals(9)-cur_vals(2))^2);
    d_EM = cur_vals(12);
    % Calculate the Forces on the Spacecraft
    F_ES_x = -constants(1)*constants(3)*constants(4)*cur_vals(1)/d_ES^3;      % I added all of the negative signs to the Forces
    F_ES_y = -constants(1)*constants(3)*constants(4)*cur_vals(2)/d_ES^3;
    F_MS_x = constants(1)*constants(2)*constants(4)*(cur_vals(8)-cur_vals(1))/d_MS^3;
    F_MS_y = constants(1)*constants(2)*constants(4)*(cur_vals(9)-cur_vals(2))/d_MS^3;
    % Calculate the Forces on the Moon
    F_EM_x = -constants(1)*constants(2)*constants(3)*cur_vals(8)/d_EM^3;
    F_EM_y = -constants(1)*constants(2)*constants(3)*cur_vals(9)/d_EM^3;
    F_SM_x = -F_MS_x;
    F_SM_y = -F_MS_y;
    % Acceleration of the S/C
    aSx = (F_MS_x+F_ES_x)/constants(4);
    aSy = (F_MS_y+F_ES_y)/constants(4);
    % Acceleration of the Moon
    aMx = (F_EM_x + F_SM_x)/constants(2);
    aMy = (F_EM_y + F_SM_y)/constants(2);
    % Velocity of the S/C 
    vSx = cur_vals(3);
    vSy = cur_vals(4);
    % Velocity of the Moon
    vMx = cur_vals(10);
    vMy = cur_vals(11);
    
        
    %% Calculate K1
    K1_rMx = vMx;       % K1 for the position of the Moon in the x direction
    K1_rMy = vMy;       % K1 for the position of the Moon in the y direction
    K1_rSx = vSx;       % K1 for the position of the Spacecraft in the x direction
    K1_rSy = vSy;       % K1 for the position of the Spacecraft in the y direction
    
    K1_vMx = aMx;       % K1 for the velocity of the Moon in the x direction
    K1_vMy = aMy;       % K1 for the velocity of the Moon in the y direction
    K1_vSx = aSx;       % K1 for the velocity of the Spacecraft in the x direction
    K1_vSy = aSy;       % K1 for the velocity of the Spacecraft in the y direction
    
    %% Calculate K2 
    % first I need to calculate new position vectors for the moon and spacecraft 
    new_M_x = cur_vals(8) + K1_rMx*h/2;
    new_M_y = cur_vals(9) + K1_rMy*h/2;
    new_S_x = cur_vals(1) + K1_rSx*h/2;
    new_S_y = cur_vals(2) + K1_rSy*h/2;
    
    d_EM = sqrt(new_M_x^2 + new_M_y^2);
    d_ES = sqrt(new_S_x^2 + new_M_y^2);
    d_MS = sqrt((new_S_x - new_M_x)^2 + (new_S_y - new_M_y)^2);
    
    % Calculate the Forces on the Spacecraft
    F_ES_x = -constants(1)*constants(3)*constants(4)*new_S_x/d_ES^3;
    F_ES_y = -constants(1)*constants(3)*constants(4)*new_S_y/d_ES^3;
    F_MS_x = constants(1)*constants(2)*constants(4)*(new_M_x-new_S_x)/d_MS^3;
    F_MS_y = constants(1)*constants(2)*constants(4)*(new_M_y-new_S_y)/d_MS^3;
    % Calculate the Forces on the Moon
    F_EM_x = -constants(1)*constants(2)*constants(3)*new_M_x/d_EM^3;
    F_EM_y = -constants(1)*constants(2)*constants(3)*new_M_y/d_EM^3;
    F_SM_x = -F_MS_x;
    F_SM_y = -F_MS_y;
    % Acceleration of the S/C
    aSx = (F_MS_x+F_ES_x)/constants(4);
    aSy = (F_MS_y+F_ES_y)/constants(4);
    % Acceleration of the Moon
    aMx = (F_EM_x + F_SM_x)/constants(2);
    aMy = (F_EM_y + F_SM_y)/constants(2);
    
    % Now get the actual K's
    K2_rMx = vMx + K1_vMx*h/2;       % K2 for the position of the Moon in the x direction
    K2_rMy = vMy + K1_vMy*h/2;       % K2 for the position of the Moon in the y direction
    K2_rSx = vSx + K1_vSx*h/2;       % K2 for the position of the Spacecraft in the x direction
    K2_rSy = vSy + K1_vSy*h/2;       % K2 for the position of the Spacecraft in the y direction
    
    K2_vMx = aMx;       % K2 for the velocity of the Moon in the x direction
    K2_vMy = aMy;       % K2 for the velocity of the Moon in the y direction
    K2_vSx = aSx;       % K2 for the velocity of the Spacecraft in the x direction
    K2_vSy = aSy;       % K2 for the velocity of the Spacecraft in the y direction
    
    %% Now get the K'3
    % first I need to calculate new position vectors for the moon and spacecraft 
    new_M_x = cur_vals(8) + K2_rMx*h/2;
    new_M_y = cur_vals(9) + K2_rMy*h/2;
    new_S_x = cur_vals(1) + K2_rSx*h/2;
    new_S_y = cur_vals(2) + K2_rSy*h/2;
    
    d_EM = sqrt(new_M_x^2 + new_M_y^2);
    d_ES = sqrt(new_S_x^2 + new_M_y^2);
    d_MS = sqrt((new_S_x - new_M_x)^2 + (new_S_y - new_M_y)^2);
    
    % Calculate the Forces on the Spacecraft
    F_ES_x = -constants(1)*constants(3)*constants(4)*new_S_x/d_ES^3;
    F_ES_y = -constants(1)*constants(3)*constants(4)*new_S_y/d_ES^3;
    F_MS_x = constants(1)*constants(2)*constants(4)*(new_M_x-new_S_x)/d_MS^3;
    F_MS_y = constants(1)*constants(2)*constants(4)*(new_M_y-new_S_y)/d_MS^3;
    % Calculate the Forces on the Moon
    F_EM_x = -constants(1)*constants(2)*constants(3)*new_M_x/d_EM^3;
    F_EM_y = -constants(1)*constants(2)*constants(3)*new_M_y/d_EM^3;
    F_SM_x = -F_MS_x;
    F_SM_y = -F_MS_y;
    % Acceleration of the S/C
    aSx = (F_MS_x+F_ES_x)/constants(4);
    aSy = (F_MS_y+F_ES_y)/constants(4);
    % Acceleration of the Moon
    aMx = (F_EM_x + F_SM_x)/constants(2);
    aMy = (F_EM_y + F_SM_y)/constants(2);
    
    % Now get the actual K's
    K3_rMx = vMx + K2_vMx*h/2;       % K2 for the position of the Moon in the x direction
    K3_rMy = vMy + K2_vMy*h/2;       % K2 for the position of the Moon in the y direction
    K3_rSx = vSx + K2_vSx*h/2;       % K2 for the position of the Spacecraft in the x direction
    K3_rSy = vSy + K2_vSy*h/2;       % K2 for the position of the Spacecraft in the y direction
    
    K3_vMx = aMx;       % K2 for the velocity of the Moon in the x direction
    K3_vMy = aMy;       % K2 for the velocity of the Moon in the y direction
    K3_vSx = aSx;       % K2 for the velocity of the Spacecraft in the x direction
    K3_vSy = aSy;       % K2 for the velocity of the Spacecraft in the y direction
    
    %% Now get the K4's
    % first I need to calculate new position vectors for the moon and spacecraft 
    new_M_x = cur_vals(8) + K3_rMx*h;
    new_M_y = cur_vals(9) + K3_rMy*h;
    new_S_x = cur_vals(1) + K3_rSx*h;
    new_S_y = cur_vals(2) + K3_rSy*h;
    
    d_EM = sqrt(new_M_x^2 + new_M_y^2);
    d_ES = sqrt(new_S_x^2 + new_M_y^2);
    d_MS = sqrt((new_S_x - new_M_x)^2 + (new_S_y - new_M_y)^2);
    
    % Calculate the Forces on the Spacecraft
    F_ES_x = -constants(1)*constants(3)*constants(4)*new_S_x/d_ES^3;
    F_ES_y = -constants(1)*constants(3)*constants(4)*new_S_y/d_ES^3;
    F_MS_x = constants(1)*constants(2)*constants(4)*(new_M_x-new_S_x)/d_MS^3;
    F_MS_y = constants(1)*constants(2)*constants(4)*(new_M_y-new_S_y)/d_MS^3;
    % Calculate the Forces on the Moon
    F_EM_x = -constants(1)*constants(2)*constants(3)*new_M_x/d_EM^3;
    F_EM_y = -constants(1)*constants(2)*constants(3)*new_M_y/d_EM^3;
    F_SM_x = -F_MS_x;
    F_SM_y = -F_MS_y;
    % Acceleration of the S/C
    aSx = (F_MS_x+F_ES_x)/constants(4);
    aSy = (F_MS_y+F_ES_y)/constants(4);
    % Acceleration of the Moon
    aMx = (F_EM_x + F_SM_x)/constants(2);
    aMy = (F_EM_y + F_SM_y)/constants(2);
    
    % Now get the actual K's
    K4_rMx = vMx + K3_vMx*h;       % K2 for the position of the Moon in the x direction
    K4_rMy = vMy + K3_vMy*h;       % K2 for the position of the Moon in the y direction
    K4_rSx = vSx + K3_vSx*h;       % K2 for the position of the Spacecraft in the x direction
    K4_rSy = vSy + K3_vSy*h;       % K2 for the position of the Spacecraft in the y direction
    
    K4_vMx = aMx;       % K2 for the velocity of the Moon in the x direction
    K4_vMy = aMy;       % K2 for the velocity of the Moon in the y direction
    K4_vSx = aSx;       % K2 for the velocity of the Spacecraft in the x direction
    K4_vSy = aSy;       % K2 for the velocity of the Spacecraft in the y direction
    
    
    %% Now get the actual change in position and velocity
    % position
    cur_vals(1) = cur_vals(1) + (h/6*(K1_rSx + K2_rSx + K3_rSx + K4_rSx));    % update the x position of the spacecraft
    cur_vals(2) = cur_vals(2) + (h/6*(K1_rSy + K2_rSy + K3_rSy + K4_rSy));    % update the y position of the spacecraft
    cur_vals(8) = cur_vals(8) + (h/6*(K1_rMx + K2_rMx + K3_rMx + K4_rMx));    % update the x position of the moon
    cur_vals(9) = cur_vals(9) + (h/6*(K1_rMy + K2_rMy + K3_rMy + K4_rMy));    % update the y position of the moon
    
    % velocity
    cur_vals(3) = cur_vals(3) + (h/6*(K1_vSx + K2_vSx + K3_vSx + K4_vSx));    % update the x velocity of the spacecraft
    cur_vals(4) = cur_vals(4) + (h/6*(K1_vSy + K2_vSy + K3_vSy + K4_vSy));    % update the y velocity of the spacecraft
    cur_vals(10) = cur_vals(10) + (h/6*(K1_vMx + K2_vMx + K3_vMx + K4_vMx));  % update the x velocity of the moon
    cur_vals(11) = cur_vals(11) + (h/6*(K1_vMy + K2_vMy + K3_vMy + K4_vMy));  % update the y velocity of the moon
    
    % update the other values
    cur_vals(5) = sqrt(cur_vals(1)^2 + cur_vals(2)^2);      % update the distance between scraft and earth
    cur_vals(6) = sqrt(cur_vals(3)^2 + cur_vals(4)^2);      % update the speed of the spacecraft
    cur_vals(12) = sqrt(cur_vals(8)^2 + cur_vals(9)^2);     % update the distance between moon and Earth
    cur_vals(13) = sqrt(cur_vals(10)^2 + cur_vals(11)^2);   % update speed of spacecraft
end