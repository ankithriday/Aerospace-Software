function [] = plot_data(data, constants)

% first plot the Earth
earth_pic = imread('Earth.tif');
[X,Y,Z] = ellipsoid(0,0,0,3*constants(6),3*constants(6),3*constants(6));
figure
h1 = surf(X,Y,-Z);
set(h1, 'CData', earth_pic, 'FaceColor', 'texturemap', 'edgecolor', 'none')
hold on

curve = animatedline('LineWidth', 2,'Color','r');
curve_moon = animatedline('Linewidth',2);
axis equal
xlabel('x')
ylabel('y')   % label the axis so that it can be used for reference of the coordinate system

set(gca,'XLim', [-2.1*constants(7) 2.1*constants(7)],'YLim', [-2.1*constants(7) 2.1*constants(7)], 'ZLim', [-4*constants(6) 4*constants(6)])
scraft = scatter3(0,0,0);
moon = scatter3(0,0,0);
set(gcf, 'Position', get(0, 'Screensize'));    % this will maximize the window

for i = floor(linspace(1,length(data),50))
    delete(scraft)
    delete(moon)  % need to delete the old points 

    
    addpoints(curve,data(i,2), data(i,3), 0);
    scraft = scatter3(data(i,2), data(i,3), 0, 15,'MarkerEdgeColor','k','MarkerFaceColor',[0 0 1]);
    % add the new points
    addpoints(curve_moon, data(i,4), data(i,5), 0);
    moon = scatter3(data(i,4),data(i,5),0,10,'MarkerEdgeColor','k', 'MarkerFaceColor',[0.25 0.25 0.25]);
    drawnow
    
end


end