close all
clear all

%% Set up Initial Conditions
profile on 
% Define Constants
G = 6.674*10^-11;      % Gravitational Constant
MM = 7.34767309*10^22; % Mass of moon in Kg
ME = 5.97219*10^24;    % Mass of Earth in Kg
MS = 28833;            % Mass of Spacecraft in Kg
RM = 1737100;          % radius of moon in m
RE = 6371000;          % radius of Earth in m
dES = 338000000;       % meters
dEM = 384403000;       % meters
vS = 1000;             % meters per second
vM = sqrt(G*ME^2/(ME+MM)/dEM);  % speed of the moon
thetaS = 50;           % degrees
thetaM = 42.5;         % degrees

constants = [G;MM;ME;MS;RM;RE;dEM;vM];



xS = dES*cosd(thetaS);
yS = dES*sind(thetaS);
vSx = vS*cosd(thetaS);
vSy = vS*sind(thetaS);
xM = dEM*cosd(thetaM);
yM = dEM*sind(thetaM);
vMx = -vM*sind(thetaM);
vMy = vM*cosd(thetaM);




Init = [xS;         % x position of spacecraft
        yS;         % y position of spacecraft
        vSx;        % x velocity of spacecraft
        vSy;        % y velocity of spacecraft
        dES;        % distance from Earth to spacecraft
        vS;         % velocity of spacecraft
        thetaS;     % angle of spacecraft relative to Earth
        xM;         % x position of moon
        yM;         % y position of moon
        vMx;        % x velocity of moon
        vMy;        % y velocity of moon
        dEM;        % distance between Earth and moon
        vM;         % velocity of moon
        thetaM];    % angle between Earth and moon

    
guess = [0 1];   % this was -1 -1
guess = guess / norm(guess);   % this is an initial guess for the thrust which I know will hit the earth
thrust_mag = 100;   % this was 200, then 80

%% Objective 1
time_s = 10;
[min_thrust_dir, min_thrust_mag,data] = Objective1(guess, thrust_mag, Init, constants, time_s, 2, 0, [],[]);  % this takes about 70 sec to run
fprintf("The minimum thrust to get back to Earth is in the direction <%.5f,%.5f> with a magnitude of %.3f m/s\n",min_thrust_dir(1),min_thrust_dir(2),min_thrust_mag);

profile viewer
plot_data(data,constants);
