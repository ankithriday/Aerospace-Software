function [save_data,stop_condition] = calculate_orbit(cur_vals, constants, time_s)

stop_condition = 0;
time = 0;
i = 1;
max_rows = 50000;   % this will help speed things up
save_data = zeros(max_rows,9);    % make max_rows x 9 zero matrix

% time (1), x pos of spacecraft (2), y pos of spacecraft (3), x pos of moon (4), y pos of moon (5), x vel of spacecraft(6), y vel of spacecraft(7), x vel of moon (8), y vel of moon (y)  
save_data = [time,cur_vals(1),cur_vals(2),cur_vals(8),cur_vals(9),cur_vals(3),cur_vals(4),cur_vals(10),cur_vals(11)];
while ~stop_condition
    % Now calculate the new value for the state variables using
    i = i + 1;   % increase the index for save_data
    time = time + time_s;
    cur_vals = rk4(cur_vals, constants, time_s);
    if i <= max_rows
        save_data(i,:) = [time,cur_vals(1),cur_vals(2),cur_vals(8),cur_vals(9),cur_vals(3),cur_vals(4),cur_vals(10),cur_vals(11)];
    else
        save_data = [save_data;time,cur_vals(1),cur_vals(2),cur_vals(8),cur_vals(9),cur_vals(3),cur_vals(4),cur_vals(10),cur_vals(11)];
    end
    % Check stop condition
    cur_vals(5) = sqrt(cur_vals(1)^2 + cur_vals(2)^2);
    
    if cur_vals(5) < constants(6)   % If the spacecraft is inside the radius of the Earth, mission success
        stop_condition = 1;    % Code 1 for mission success
    elseif feval(@inside_moon,cur_vals(8),cur_vals(9),constants(5),cur_vals(1),cur_vals(2))
        stop_condition = 2;   % code 2 for hitting the moon
    elseif cur_vals(5) > 2*constants(7)
        stop_condition = 3;   % Code 3 for getting too far away
    end
end
% now trim off the bottom entries if the space craft was faster
if (time / time_s) < max_rows
    save_data(time/time_s,:) = [];
end

end