%% Ankit Hriday
%% 23rd Jan 2018
%% Assignment-1
%% Problem-3 max attainable height calculator
%% Define function
function [max_h] = max_attain_alt(r,w_payload,w_balloon,MW)
% call w_total to know the total weight
w_total = total_weight(r,w_payload,w_balloon,MW);
% initial height is 0
h = 0;
% calculate w_air at initial height
w_air = weight_air(r,h)
% run the loop till w_total<w_air so that we have the answer
while w_total<w_air
w_air = weight_air(r,h);
% increase h by 10 every iteration
h = h+10;
end
% final h is the max_h
max_h = h;
end