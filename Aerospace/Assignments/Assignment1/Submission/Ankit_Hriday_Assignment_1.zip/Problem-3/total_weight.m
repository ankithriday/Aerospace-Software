%% Ankit Hriday
%% 23rd Jan 2018
%% Assignment-1
%% Problem-3 Total weight calculator
function [w_total] = total_weight(r,w_payload,w_balloon,MW)
%% Constants
rho_0 = 1.225;
%% Gas weight calculation
w_gas = (MW/28.966)*(4*pi*rho_0*r^3)/3;
%% Combine all weights
w_total = w_gas+w_payload+w_balloon;
end