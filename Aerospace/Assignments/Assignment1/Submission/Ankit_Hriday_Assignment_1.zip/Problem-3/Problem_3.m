%% Ankit Hriday
%% 23rd Jan 2018
%% Assignment-1
%% Problem-3 Main
%% Hopusekeeping
clear all; close all; clc
%% Givens
r = 3.5; w_payload = 5; w_balloon = 0.6; MW = 4.02;
%% Call the function
max_h = max_attain_alt(r,w_payload,w_balloon,MW)