%% Ankit Hriday
%% 23rd Jan 2018
%% Assignment-1
%% Problem-3 Weight of Air calculator
%% Define function
function [w_air] = weight_air(r,h)
%% Calculate T and P
if h <= 11000
    T = 15.04 - 0.00649*h;
    P = 101.29*((T+273.15)/288.08)^(5.256);
elseif 11000 < h && h <= 25000
    T = -56.46;
    P = 22.65*exp(1.73-0.000157*h);
else
    T = -131.21 + 0.00299*h;
    P = 2.488*((T+273.15)/216.6)^(-11.388)
end
% convert it to rho
rho = P/(0.2869*(T+273.15));
% calculate w_air from the rho
w_air = rho*4*pi*r^3/3;
end