%% Ankit Hriday
%% Assignment-1 Problem-1
%% 22nd Jan 2018
%% Housekeeping
clear all; close all; clc
%% Constants
g = 9.8;
%% Inputs
theta = input('Enter the angle theta in degrees: ');
V = input('Enter the velocity: ');
%% Solve for t_term and define t
b = -V*sind(theta);
a = 0.5*g;
c = 0;
t_term = (-b+sqrt(b^2-4*a*c))/(2*a);
t = 0:0.001:t_term;
%% Find the displacements
for i=1:length(t);
x(i) = V*cosd(theta)*t(i);
y(i) = -0.5*g*(t(i))^2 + V*sind(theta)*t(i); 
end
%% Plot
subplot(2,1,1)
plot(t,x)
grid on
xlabel('Time (s)'); ylabel('X position (m)')
title('X as a function of time')
hold on 
subplot(2,1,2)
plot(t,y)
xlabel('Time (s)'); ylabel('Y position (m)')
title('Y as a function of time')
grid on