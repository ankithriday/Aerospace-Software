%% Ankit Hriday
%% 22nd Jan 2018
%% Assignment-1
%% Problem-2 Best-fit calculator
function [m,b] = best_fit(x,y)
%% Calculate A,B,C and D
% N is the total number of data
N = length(x);
% set initial conditions to 0 for faster operation
A = 0; B = 0; C = 0; D = 0;
% calculate A, B , C and D using the loops
% Add A,B,C and D to previous values every iteration
for i=1:length(x)
    A = A+x(i);
    B = B+y(i); 
    C = C+x(i)*y(i) ;
    D = D+(x(i))^2;
end
%% Calculate m and b using the formulae
m = (A*B-N*C)/(A^2-N*D);
b = (A*C-B*D)/(A^2-N*D);
end