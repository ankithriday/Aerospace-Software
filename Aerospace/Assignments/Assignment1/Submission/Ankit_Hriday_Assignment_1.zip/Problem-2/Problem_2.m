%% Ankit Hriday
%% 22nd Jan 2018
%% Assignment-1
%% Problem-2 Main
%% Define function
alpha = [-5 -2 0 2 3 5 7 9 14];
C_l = [-0.008 -.003 .001 .005 .007 .006 .009 .0145 .019];
[m,b] = best_fit(alpha, C_l)

%% Plot original Data
plot(alpha,C_l)

%% Plot calculated data
calc_Cl = m*alpha + b ; 
hold on
plot(alpha,calc_Cl)
grid on
legend('Actual C_L','Calculated C_L')
xlabel('Alpha'); ylabel('C_L')